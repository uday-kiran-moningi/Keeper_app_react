const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.get("/help", function (req, res) {
  res.send("working");
});

app.listen(process.env.PORT, function () {
  console.log("listening");
});
