import React from "react";
import year from "./year";
function Footer() {
  return (
    <footer className="footer">
      <p>copyrights {year}</p>
    </footer>
  );
}

export default Footer;
