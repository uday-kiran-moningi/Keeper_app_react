const year = new Date().getFullYear();

export default year;
