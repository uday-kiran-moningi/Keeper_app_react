import React from "react";
import HighlightIcon from "@material-ui/icons/Highlight";
import { useEffect, useState } from "react";

function Header() {
  const [time, setTime] = useState(new Date().toLocaleTimeString());
  useEffect(() => {
    const t = setInterval(() => {
      setTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => {
      clearInterval(t);
    };
  }, []);
  // console.log(new Date().toLocaleTimeString());
  return (
    <header>
      <div className="heading">
        <h1>
          <HighlightIcon />
          Keeper
        </h1>
        <h1>{time}</h1>
      </div>
    </header>
  );
}

export default Header;
